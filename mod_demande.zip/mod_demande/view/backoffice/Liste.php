<?php
session_start();
include_once __DIR__ . '/../../controller/demandeC.php';
include_once __DIR__ . '/../../controller/categorieC.php';

$dc         = new demandeC();
$cc         = new categorieC();
$demandes   = $dc->listeDemandes()->fetchAll();
$categories = $cc->listeCategories()->fetchAll();

$total     = count($demandes);
$attente   = count(array_filter($demandes, fn($d) => $d['statut'] === 'en_attente'));
$approuvee = count(array_filter($demandes, fn($d) => $d['statut'] === 'approuvee'));
$rejetee   = count(array_filter($demandes, fn($d) => $d['statut'] === 'rejetee'));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin – Liste des Demandes</title>
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/font-awesome/css/all.min.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/overlay-scrollbar/css/overlayscrollbars.min.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/css/style.css">
</head>
<body>

<!-- Sidebar -->
<nav class="navbar sidebar navbar-expand-xl navbar-light">
    <div class="offcanvas-body sidebar-content d-flex flex-column pt-4">
        <a class="navbar-brand mb-4" href="Liste.php">
            <img class="navbar-brand-item" src="/template_booking_bootstrap/assets/images/logo.svg" alt="logo">
        </a>
        <ul class="navbar-nav flex-column" id="navbar-sidebar">
            <li class="nav-item">
                <a href="Liste.php" class="nav-link active">
                    <i class="bi bi-ui-checks-grid me-2"></i>Demandes
                </a>
            </li>
            <li class="nav-item">
                <a href="Categories.php" class="nav-link">
                    <i class="bi bi-tags me-2"></i>Catégories
                </a>
            </li>
            <li class="nav-item mt-3">
                <a href="../frontoffice/Liste.php" class="nav-link">
                    <i class="bi bi-globe me-2"></i>Front-Office
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="page-content">
    <nav class="navbar top-bar navbar-light py-0 px-3 px-xl-4">
        <div class="ms-auto d-flex align-items-center gap-2">
            <span class="text-muted small">Back-Office Admin</span>
            <div class="avatar avatar-sm">
                <img class="avatar-img rounded-circle" src="/template_booking_bootstrap/assets/images/avatar/01.jpg" alt="admin">
            </div>
        </div>
    </nav>

    <div class="container-fluid px-3 px-xl-4 py-4">

        <!-- Flash messages -->
        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle me-2"></i><?= $_SESSION['success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <!-- Title -->
        <div class="d-sm-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0"><i class="bi bi-card-list me-2 text-primary"></i>Liste des Demandes</h1>

        </div>

        <!-- Stats -->
        <div class="row g-4 mb-4">
            <div class="col-sm-6 col-lg-3">
                <div class="card border-0 shadow-sm text-center py-3">
                    <div class="fs-1 text-primary"><i class="bi bi-card-list"></i></div>
                    <h3 class="fw-bold mb-0"><?= $total ?></h3>
                    <p class="text-muted small mb-0">Total</p>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="card border-0 shadow-sm text-center py-3">
                    <div class="fs-1 text-warning"><i class="bi bi-clock-history"></i></div>
                    <h3 class="fw-bold mb-0"><?= $attente ?></h3>
                    <p class="text-muted small mb-0">En attente</p>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="card border-0 shadow-sm text-center py-3">
                    <div class="fs-1 text-success"><i class="bi bi-check-circle"></i></div>
                    <h3 class="fw-bold mb-0"><?= $approuvee ?></h3>
                    <p class="text-muted small mb-0">Approuvées</p>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="card border-0 shadow-sm text-center py-3">
                    <div class="fs-1 text-danger"><i class="bi bi-x-circle"></i></div>
                    <h3 class="fw-bold mb-0"><?= $rejetee ?></h3>
                    <p class="text-muted small mb-0">Rejetées</p>
                </div>
            </div>
        </div>

        <!-- Table -->
        <div class="card shadow">
            <div class="card-body">
                <div class="bg-light rounded p-3 d-none d-lg-block">
                    <div class="row g-3">
                        <div class="col-lg-2"><h6 class="mb-0">Utilisateur</h6></div>
                        <div class="col-lg-3"><h6 class="mb-0">Email</h6></div>
                        <div class="col-lg-2"><h6 class="mb-0">Catégorie</h6></div>
                        <div class="col-lg-2"><h6 class="mb-0">Date</h6></div>
                        <div class="col-lg-1"><h6 class="mb-0">Statut</h6></div>
                        <div class="col-lg-2"><h6 class="mb-0">Actions</h6></div>
                    </div>
                </div>

                <?php if (empty($demandes)): ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inbox fs-1"></i>
                        <p class="mt-2">Aucune demande pour le moment.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($demandes as $d): ?>
                    <?php
                    $badgeClass = match($d['statut']) {
                        'approuvee' => 'bg-success bg-opacity-10 text-success',
                        'rejetee'   => 'bg-danger bg-opacity-10 text-danger',
                        default     => 'bg-warning bg-opacity-10 text-warning'
                    };
                    $label = match($d['statut']) {
                        'approuvee' => 'Approuvée',
                        'rejetee'   => 'Rejetée',
                        default     => 'En attente'
                    };
                    ?>
                    <div class="row align-items-center border-bottom g-3 px-2 py-3">
                        <div class="col-lg-2">
                            <span class="fw-semibold small"><?= htmlspecialchars($d['utilisateur']) ?></span>
                        </div>
                        <div class="col-lg-3">
                            <span class="small"><?= htmlspecialchars($d['email']) ?></span>
                        </div>
                        <div class="col-lg-2">
                            <span class="badge bg-primary bg-opacity-10 text-primary"><?= htmlspecialchars($d['categorie_nom']) ?></span>
                        </div>
                        <div class="col-lg-2">
                            <span class="small"><?= date('d/m/Y', strtotime($d['created_at'])) ?></span>
                        </div>
                        <div class="col-lg-1">
                            <span class="badge <?= $badgeClass ?>"><?= $label ?></span>
                        </div>
                        <div class="col-lg-2 d-flex gap-1">
                            <a href="Detail.php?id=<?= $d['id'] ?>" class="btn btn-sm btn-light mb-0">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="../../controller/SupprimerDemande.php?id=<?= $d['id'] ?>"
                               class="btn btn-sm btn-danger mb-0"
                               onclick="return confirm('Supprimer cette demande ?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<!-- Modal Ajouter -->
<div class="modal fade" id="modalAjouter" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Nouvelle Demande</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="../../controller/AjouterDemande.php" method="POST" enctype="multipart/form-data" id="formAjouter" novalidate>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Nom complet <span class="text-danger">*</span></label>
                            <input type="text" name="utilisateur" id="utilisateur" class="form-control" placeholder="Ex : Ahmed Ben Ali">
                            <div class="invalid-feedback" id="err_utilisateur"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                            <input type="text" name="email" id="email" class="form-control" placeholder="exemple@email.com">
                            <div class="invalid-feedback" id="err_email"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Catégorie <span class="text-danger">*</span></label>
                            <select name="categorie_id" id="categorie_id" class="form-select">
                                <option value="">-- Sélectionner --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['nom']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback" id="err_categorie"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Document <span class="text-danger">*</span></label>
                            <input type="file" name="document" id="document" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                            <div class="invalid-feedback" id="err_document"></div>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Description</label>
                            <textarea name="description" class="form-control" rows="2" placeholder="Ex : CIN, certificat…"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-send me-2"></i>Soumettre</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="/template_booking_bootstrap/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="/template_booking_bootstrap/assets/vendor/overlay-scrollbar/js/overlayscrollbars.min.js"></script>
<script>
document.getElementById('formAjouter').addEventListener('submit', function(e) {
    let valid = true;
    function showErr(inputId, errId, msg) {
        document.getElementById(inputId).classList.add('is-invalid');
        document.getElementById(errId).innerHTML = msg;
        valid = false;
    }
    function clearErr(inputId, errId) {
        document.getElementById(inputId).classList.remove('is-invalid');
        document.getElementById(errId).innerHTML = '';
    }
    clearErr('utilisateur','err_utilisateur');
    clearErr('email','err_email');
    clearErr('categorie_id','err_categorie');
    clearErr('document','err_document');

    if (document.getElementById('utilisateur').value.trim().length < 3)
        showErr('utilisateur','err_utilisateur','Le nom doit contenir au moins 3 caractères.');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(document.getElementById('email').value.trim()))
        showErr('email','err_email','Adresse e-mail invalide.');
    if (document.getElementById('categorie_id').value === '')
        showErr('categorie_id','err_categorie','Veuillez sélectionner une catégorie.');
    const doc = document.getElementById('document');
    if (!doc.files || doc.files.length === 0)
        showErr('document','err_document','Un document est obligatoire.');
    if (!valid) e.preventDefault();
});
</script>
</body>
</html>
