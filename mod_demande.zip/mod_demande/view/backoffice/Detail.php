<?php
session_start();
include_once __DIR__ . '/../../controller/demandeC.php';

$dc             = new demandeC();
$demande        = $dc->getDemande($_GET['id']);
$justifications = $dc->getJustifications($_GET['id']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détail Demande</title>
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/font-awesome/css/all.min.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/overlay-scrollbar/css/overlayscrollbars.min.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/css/style.css">
</head>
<body>

<!-- Sidebar -->
<nav class="navbar sidebar navbar-expand-xl navbar-light">
    <div class="offcanvas-body sidebar-content d-flex flex-column pt-4">
        <a class="navbar-brand mb-4" href="Liste.php">
            <img class="navbar-brand-item" src="/template_booking_bootstrap/assets/images/logo.svg" alt="logo">
        </a>
        <ul class="navbar-nav flex-column" id="navbar-sidebar">
            <li class="nav-item">
                <a href="Liste.php" class="nav-link active">
                    <i class="bi bi-ui-checks-grid me-2"></i>Demandes
                </a>
            </li>
            <li class="nav-item">
                <a href="Categories.php" class="nav-link">
                    <i class="bi bi-tags me-2"></i>Catégories
                </a>
            </li>
            <li class="nav-item mt-3">
                <a href="../frontoffice/Liste.php" class="nav-link">
                    <i class="bi bi-globe me-2"></i>Front-Office
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="page-content">
    <nav class="navbar top-bar navbar-light py-0 px-3 px-xl-4">
        <div class="ms-auto d-flex align-items-center gap-2">
            <span class="text-muted small">Back-Office Admin</span>
            <div class="avatar avatar-sm">
                <img class="avatar-img rounded-circle" src="/template_booking_bootstrap/assets/images/avatar/01.jpg" alt="admin">
            </div>
        </div>
    </nav>

    <div class="container-fluid px-3 px-xl-4 py-4">

        <!-- Flash -->
        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= $_SESSION['success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <!-- Title -->
        <div class="d-sm-flex justify-content-between align-items-center mb-4">
            <div>
                <a href="Liste.php" class="btn btn-outline-secondary btn-sm mb-2">
                    <i class="bi bi-arrow-left me-1"></i>Retour
                </a>
                <h1 class="h3 mb-0">Détail Demande #<?= $demande['id'] ?></h1>
            </div>
            <div class="d-flex gap-2 mt-2 mt-sm-0">
                <?php if ($demande['statut'] !== 'approuvee'): ?>
                <a href="../../controller/UpdateStatut.php?id=<?= $demande['id'] ?>&statut=approuvee"
                   class="btn btn-success"
                   onclick="return confirm('Approuver cette demande ?')">
                    <i class="bi bi-check-circle me-1"></i>Approuver
                </a>
                <?php endif; ?>
                <?php if ($demande['statut'] !== 'rejetee'): ?>
                <a href="../../controller/UpdateStatut.php?id=<?= $demande['id'] ?>&statut=rejetee"
                   class="btn btn-danger"
                   onclick="return confirm('Rejeter cette demande ?')">
                    <i class="bi bi-x-circle me-1"></i>Rejeter
                </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="row g-4">
            <!-- Info -->
            <div class="col-lg-6">
                <div class="card shadow h-100">
                    <div class="card-header bg-primary bg-opacity-10">
                        <h5 class="mb-0 text-primary"><i class="bi bi-person-circle me-2"></i>Informations</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-borderless mb-0">
                            <tr>
                                <td class="fw-semibold text-muted">Nom</td>
                                <td><?= htmlspecialchars($demande['utilisateur']) ?></td>
                            </tr>
                            <tr>
                                <td class="fw-semibold text-muted">Email</td>
                                <td><?= htmlspecialchars($demande['email']) ?></td>
                            </tr>
                            <tr>
                                <td class="fw-semibold text-muted">Catégorie</td>
                                <td><span class="badge bg-primary bg-opacity-10 text-primary"><?= htmlspecialchars($demande['categorie_nom']) ?></span></td>
                            </tr>
                            <tr>
                                <td class="fw-semibold text-muted">Date</td>
                                <td><?= date('d/m/Y à H:i', strtotime($demande['created_at'])) ?></td>
                            </tr>
                            <tr>
                                <td class="fw-semibold text-muted">Statut</td>
                                <td>
                                <?php
                                $badgeClass = match($demande['statut']) {
                                    'approuvee' => 'bg-success bg-opacity-10 text-success',
                                    'rejetee'   => 'bg-danger bg-opacity-10 text-danger',
                                    default     => 'bg-warning bg-opacity-10 text-warning'
                                };
                                $label = match($demande['statut']) {
                                    'approuvee' => '✅ Approuvée',
                                    'rejetee'   => '❌ Rejetée',
                                    default     => '⏳ En attente'
                                };
                                ?>
                                <span class="badge <?= $badgeClass ?>"><?= $label ?></span>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Documents -->
            <div class="col-lg-6">
                <div class="card shadow h-100">
                    <div class="card-header bg-warning bg-opacity-10">
                        <h5 class="mb-0 text-warning"><i class="bi bi-paperclip me-2"></i>Documents</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($justifications)): ?>
                            <p class="text-muted text-center py-4">Aucun document joint.</p>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($justifications as $j): ?>
                                <?php
                                $ext  = strtolower(pathinfo($j['document'], PATHINFO_EXTENSION));
                                $icon = match($ext) {
                                    'pdf'  => 'bi-file-earmark-pdf text-danger',
                                    'jpg','jpeg','png' => 'bi-file-earmark-image text-success',
                                    default => 'bi-file-earmark text-secondary'
                                };
                                ?>
                                <div class="list-group-item px-0 d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="bi <?= $icon ?> fs-3"></i>
                                        <div>
                                            <p class="mb-0 small fw-semibold"><?= htmlspecialchars($j['document']) ?></p>
                                            <?php if (!empty($j['description'])): ?>
                                                <small class="text-muted"><?= htmlspecialchars($j['description']) ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <a href="/projet_v2/uploads/<?= $j['document'] ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye me-1"></i>Voir
                                    </a>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4 text-end">
            <a href="../../controller/SupprimerDemande.php?id=<?= $demande['id'] ?>"
               class="btn btn-outline-danger"
               onclick="return confirm('Supprimer définitivement cette demande ?')">
                <i class="bi bi-trash me-1"></i>Supprimer
            </a>
        </div>

    </div>
</div>

<script src="/template_booking_bootstrap/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="/template_booking_bootstrap/assets/vendor/overlay-scrollbar/js/overlayscrollbars.min.js"></script>
</body>
</html>
