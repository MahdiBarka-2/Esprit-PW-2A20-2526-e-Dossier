<?php
session_start();
include_once __DIR__ . '/../../controller/categorieC.php';

$cc         = new categorieC();
$categories = $cc->listeCategories()->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin – Catégories</title>
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/font-awesome/css/all.min.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/overlay-scrollbar/css/overlayscrollbars.min.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/css/style.css">
</head>
<body>

<!-- Sidebar -->
<nav class="navbar sidebar navbar-expand-xl navbar-light">
    <div class="offcanvas-body sidebar-content d-flex flex-column pt-4">
        <a class="navbar-brand mb-4" href="Liste.php">
            <img class="navbar-brand-item" src="/template_booking_bootstrap/assets/images/logo.svg" alt="logo">
        </a>
        <ul class="navbar-nav flex-column" id="navbar-sidebar">
            <li class="nav-item">
                <a href="Liste.php" class="nav-link">
                    <i class="bi bi-ui-checks-grid me-2"></i>Demandes
                </a>
            </li>
            <li class="nav-item">
                <a href="Categories.php" class="nav-link active">
                    <i class="bi bi-tags me-2"></i>Catégories
                </a>
            </li>
            <li class="nav-item mt-3">
                <a href="../frontoffice/Liste.php" class="nav-link">
                    <i class="bi bi-globe me-2"></i>Front-Office
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="page-content">
    <nav class="navbar top-bar navbar-light py-0 px-3 px-xl-4">
        <div class="ms-auto d-flex align-items-center gap-2">
            <span class="text-muted small">Back-Office Admin</span>
            <div class="avatar avatar-sm">
                <img class="avatar-img rounded-circle" src="/template_booking_bootstrap/assets/images/avatar/01.jpg" alt="admin">
            </div>
        </div>
    </nav>

    <div class="container-fluid px-3 px-xl-4 py-4">

        <!-- Flash -->
        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= $_SESSION['success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        <?php if (!empty($_SESSION['errors'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">
                    <?php foreach ($_SESSION['errors'] as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; unset($_SESSION['errors']); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Title -->
        <div class="d-sm-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0"><i class="bi bi-tags me-2 text-primary"></i>Catégories</h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAjouter">
                <i class="bi bi-plus-circle me-2"></i>Nouvelle Catégorie
            </button>
        </div>

        <!-- Table -->
        <div class="card shadow">
            <div class="card-body">
                <div class="bg-light rounded p-3 d-none d-lg-block">
                    <div class="row">
                        <div class="col-lg-1"><h6 class="mb-0">#</h6></div>
                        <div class="col-lg-3"><h6 class="mb-0">Nom</h6></div>
                        <div class="col-lg-6"><h6 class="mb-0">Description</h6></div>
                        <div class="col-lg-2"><h6 class="mb-0">Action</h6></div>
                    </div>
                </div>

                <?php if (empty($categories)): ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-tags fs-1"></i>
                        <p class="mt-2">Aucune catégorie.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($categories as $cat): ?>
                    <div class="row align-items-center border-bottom g-3 px-2 py-3">
                        <div class="col-lg-1"><span class="text-muted small">#<?= $cat['id'] ?></span></div>
                        <div class="col-lg-3"><span class="fw-semibold"><?= htmlspecialchars($cat['nom']) ?></span></div>
                        <div class="col-lg-6"><span class="text-muted small"><?= htmlspecialchars($cat['description'] ?? '—') ?></span></div>
                        <div class="col-lg-2">
                            <a href="../../controller/SupprimerCategorie.php?id=<?= $cat['id'] ?>"
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Supprimer cette catégorie ?')">
                                <i class="bi bi-trash me-1"></i>Supprimer
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<!-- Modal Ajouter Catégorie -->
<div class="modal fade" id="modalAjouter" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-tag me-2"></i>Nouvelle Catégorie</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="../../controller/AjouterCategorie.php" method="POST" id="formCat" novalidate>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nom <span class="text-danger">*</span></label>
                        <input type="text" name="nom" id="cat_nom" class="form-control" placeholder="Ex : Logement">
                        <div class="invalid-feedback" id="err_nom"></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <textarea name="description" class="form-control" rows="2" placeholder="Description optionnelle…"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-2"></i>Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="/template_booking_bootstrap/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="/template_booking_bootstrap/assets/vendor/overlay-scrollbar/js/overlayscrollbars.min.js"></script>
<script>
document.getElementById('formCat').addEventListener('submit', function(e) {
    let valid = true;
    const nom = document.getElementById('cat_nom');
    const err = document.getElementById('err_nom');
    nom.classList.remove('is-invalid');
    err.innerHTML = '';
    if (nom.value.trim().length < 2) {
        nom.classList.add('is-invalid');
        err.innerHTML = 'Le nom doit contenir au moins 2 caractères.';
        valid = false;
    }
    if (!valid) e.preventDefault();
});
</script>
</body>
</html>
