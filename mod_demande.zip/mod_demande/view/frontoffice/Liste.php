<?php
session_start();
include_once __DIR__ . '/../../controller/demandeC.php';
include_once __DIR__ . '/../../controller/categorieC.php';

$dc         = new demandeC();
$cc         = new categorieC();
$demandes   = $dc->listeDemandes()->fetchAll();
$categories = $cc->listeCategories()->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portail des Demandes</title>
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/font-awesome/css/all.min.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/vendor/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="/template_booking_bootstrap/assets/css/style.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-xl navbar-light">
    <div class="container">
        <a class="navbar-brand" href="Liste.php">
            <img class="navbar-brand-item" src="/template_booking_bootstrap/assets/images/logo.svg" alt="logo">
        </a>
        <div class="ms-auto d-flex gap-2">
            <a href="../backoffice/Liste.php" class="btn btn-sm btn-outline-primary mb-0">
                <i class="bi bi-shield-lock me-1"></i>Back-Office
            </a>

        </div>
    </div>
</nav>

<!-- Hero -->
<section style="background: linear-gradient(135deg,#1d3461,#376cbe); min-height:200px;"
         class="d-flex align-items-center">
    <div class="container text-white text-center py-5">
        <h1 class="display-6 fw-bold mb-2">Portail des Demandes Étudiantes</h1>
        <p class="mb-3 opacity-75">Soumettez et suivez vos demandes administratives en ligne.</p>
        <button class="btn btn-light btn-lg px-5" data-bs-toggle="modal" data-bs-target="#modalAjouter">
            <i class="bi bi-plus-circle me-2"></i>Faire une demande
        </button>
    </div>
</section>

<div class="container py-5">

    <!-- Flash messages -->
    <?php if (!empty($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i><?= $_SESSION['success'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    <?php if (!empty($_SESSION['errors'])): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <ul class="mb-0">
                <?php foreach ($_SESSION['errors'] as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; unset($_SESSION['errors']); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Step guide -->
    <div class="card border-0 shadow-sm py-4 px-3 mb-5">
        <h5 class="text-center fw-bold mb-4"><i class="bi bi-signpost-2 me-2 text-primary"></i>Comment soumettre votre demande ?</h5>
        <div class="row g-3 text-center">
            <div class="col-md-4">
                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-5 mx-auto mb-2" style="width:50px;height:50px;">1</div>
                <i class="bi bi-tags fs-2 text-primary d-block"></i>
                <h6 class="fw-semibold">Choisir une catégorie</h6>
                <p class="text-muted small">Logement, Bourse, Carte, Certificat…</p>
            </div>
            <div class="col-md-4">
                <div class="rounded-circle bg-warning text-white d-flex align-items-center justify-content-center fw-bold fs-5 mx-auto mb-2" style="width:50px;height:50px;">2</div>
                <i class="bi bi-paperclip fs-2 text-warning d-block"></i>
                <h6 class="fw-semibold">Joindre vos documents</h6>
                <p class="text-muted small">CIN, certificat d'inscription, fiche…</p>
            </div>
            <div class="col-md-4">
                <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center fw-bold fs-5 mx-auto mb-2" style="width:50px;height:50px;">3</div>
                <i class="bi bi-send-check fs-2 text-success d-block"></i>
                <h6 class="fw-semibold">Soumettre la demande</h6>
                <p class="text-muted small">Suivez le statut ci-dessous.</p>
            </div>
        </div>
    </div>

    <!-- Liste des demandes -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0"><i class="bi bi-list-check me-2 text-primary"></i>Mes demandes</h2>
        <span class="badge bg-primary"><?= count($demandes) ?> demande(s)</span>
    </div>

    <?php if (empty($demandes)): ?>
        <div class="text-center py-5 text-muted">
            <i class="bi bi-inbox fs-1 d-block mb-3"></i>
            <p>Aucune demande pour le moment.</p>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAjouter">
                <i class="bi bi-plus-circle me-2"></i>Soumettre ma première demande
            </button>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($demandes as $d): ?>
            <?php
            $badgeClass = match($d['statut']) {
                'approuvee' => 'bg-success',
                'rejetee'   => 'bg-danger',
                default     => 'bg-warning'
            };
            $label = match($d['statut']) {
                'approuvee' => 'Approuvée',
                'rejetee'   => 'Rejetée',
                default     => 'En attente'
            };
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="badge bg-primary bg-opacity-10 text-primary"><?= htmlspecialchars($d['categorie_nom']) ?></span>
                            <span class="badge <?= $badgeClass ?>"><?= $label ?></span>
                        </div>
                        <h6 class="fw-bold"><?= htmlspecialchars($d['utilisateur']) ?></h6>
                        <p class="text-muted small mb-0"><i class="bi bi-envelope me-1"></i><?= htmlspecialchars($d['email']) ?></p>
                        <p class="text-muted small mb-0"><i class="bi bi-calendar me-1"></i><?= date('d/m/Y', strtotime($d['created_at'])) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<!-- Modal Ajouter -->
<div class="modal fade" id="modalAjouter" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Nouvelle Demande</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="../../controller/AjouterDemande.php" method="POST" enctype="multipart/form-data" id="formAjouter" novalidate>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Nom complet <span class="text-danger">*</span></label>
                            <input type="text" name="utilisateur" id="utilisateur" class="form-control"
                                   value="<?= htmlspecialchars($_SESSION['old']['utilisateur'] ?? '') ?>"
                                   placeholder="Ex : Ahmed Ben Ali">
                            <div class="invalid-feedback" id="err_utilisateur"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                            <input type="text" name="email" id="email" class="form-control"
                                   value="<?= htmlspecialchars($_SESSION['old']['email'] ?? '') ?>"
                                   placeholder="exemple@email.com">
                            <div class="invalid-feedback" id="err_email"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Catégorie <span class="text-danger">*</span></label>
                            <select name="categorie_id" id="categorie_id" class="form-select">
                                <option value="">-- Sélectionner --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['nom']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback" id="err_categorie"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Document justificatif <span class="text-danger">*</span></label>
                            <input type="file" name="document" id="document" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                            <small class="text-muted">PDF, JPG ou PNG – max 5 Mo</small>
                            <div class="invalid-feedback" id="err_document"></div>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Description du document</label>
                            <textarea name="description" class="form-control" rows="2" placeholder="Ex : CIN, certificat d'inscription…"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-send me-2"></i>Soumettre</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php unset($_SESSION['old']); ?>

<footer class="py-3 text-center text-muted small border-top mt-5">
    © <?= date('Y') ?> – Système de Gestion des Demandes
</footer>

<script src="/template_booking_bootstrap/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Validation JS (sans HTML5)
document.getElementById('formAjouter').addEventListener('submit', function(e) {
    let valid = true;

    function showErr(inputId, errId, msg) {
        document.getElementById(inputId).classList.add('is-invalid');
        document.getElementById(errId).innerHTML = msg;
        valid = false;
    }
    function clearErr(inputId, errId) {
        document.getElementById(inputId).classList.remove('is-invalid');
        document.getElementById(errId).innerHTML = '';
    }

    clearErr('utilisateur','err_utilisateur');
    clearErr('email','err_email');
    clearErr('categorie_id','err_categorie');
    clearErr('document','err_document');

    if (document.getElementById('utilisateur').value.trim().length < 3)
        showErr('utilisateur','err_utilisateur','Le nom doit contenir au moins 3 caractères.');

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(document.getElementById('email').value.trim()))
        showErr('email','err_email','Adresse e-mail invalide.');

    if (document.getElementById('categorie_id').value === '')
        showErr('categorie_id','err_categorie','Veuillez sélectionner une catégorie.');

    const doc = document.getElementById('document');
    if (!doc.files || doc.files.length === 0)
        showErr('document','err_document','Un document justificatif est obligatoire.');

    if (!valid) e.preventDefault();
});
</script>
</body>
</html>
