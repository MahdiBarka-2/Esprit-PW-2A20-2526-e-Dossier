<?php
include __DIR__ . '/../controllers/EvenementController.php';

$controller = new EvenementC();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->addEvenement($_POST);

    header("Location: index.php?view=back");
    exit;
}

echo "Invalid request";