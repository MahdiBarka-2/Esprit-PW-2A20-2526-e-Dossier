<?php
require_once __DIR__ . '/../controllers/EvenementController.php';

$controller = new EvenementC();

$events = $controller->listeEvenement();
$active_events = $controller->findActive();




$view       = $_GET['view'] ?? 'front';
$tab        = $_GET['tab']  ?? 'all';
$show_modal = isset($_GET['modal']);
$edit_id    = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;

$edit_event = null;
if ($edit_id > 0) {
    $edit_event = $controller->findById($edit_id);
}

$f = [
    'titre'        => $_GET['titre']        ?? '',
    'description'  => $_GET['description']  ?? '',
    'date_debut'   => $_GET['date_debut']   ?? '',
    'date_fin'     => $_GET['date_fin']     ?? '',
    'lieu'         => $_GET['lieu']         ?? '',
    'capacite_max' => $_GET['capacite_max'] ?? '',
    'statut'       => $_GET['statut']       ?? 'active',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Booking – Portail des Événements</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <div class="nav">
    <div class="logo">
      <div class="logo-circle">
        <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
      </div>
      Booking
    </div>
    <div class="nav-right">
      <?php if ($view === 'front'): ?>
        <a href="?view=back" class="btn-outline">Admin</a>
      <?php else: ?>
        <a href="?view=front" class="btn-outline">Front-Office</a>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($view === 'front'): ?>
  <div id="view-front">
    <div class="hero">
      <h1>Portail des Événements</h1>
      <p>Découvrez et participez aux événements disponibles</p>
    </div>
    <div class="content">
      <div class="section-head">
        <div class="section-title">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6C5CE7" stroke-width="2">
            <rect x="3" y="4" width="18" height="18" rx="2"/>
            <line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8" y1="2" x2="8" y2="6"/>
            <line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
          Événements actifs
        </div>
        <span class="badge-count"><?= count($active_events) ?> événement(s)</span>
      </div>

      <div class="tabs">
        <a href="?view=front&tab=all"  class="tab <?= $tab === 'all'  ? 'active' : '' ?>">Tous</a>
        <a href="?view=front&tab=mine" class="tab <?= $tab === 'mine' ? 'active' : '' ?>">Mes participations</a>
      </div>

      <?php if ($tab === 'all'): ?>
        <?php if (empty($active_events)): ?>
          <div class="empty">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <rect x="3" y="4" width="18" height="18" rx="2"/>
              <line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/>
              <line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
            <p>Aucun événement actif pour le moment.</p>
          </div>
        <?php else: ?>
          <div class="events-grid">
            <?php foreach ($active_events as $e): ?>
            <?php
              $cnt     = $counts_map[$e['id']] ?? 0;
              $cap     = $e['capacite_max'];
              $is_full = $cap !== null && $cnt >= (int)$cap;
            ?>
            <div class="event-card">
              <h3><?= htmlspecialchars($e['titre']) ?></h3>
              <?php if ($e['lieu']): ?>
              <div class="event-meta">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
                <?= htmlspecialchars($e['lieu']) ?>
              </div>
              <?php endif; ?>
              <div class="event-meta">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="3" y="4" width="18" height="18" rx="2"/>
                  <line x1="3" y1="10" x2="21" y2="10"/>
                </svg>
                <?= htmlspecialchars($e['date_debut']) ?>
                <?= $e['date_fin'] ? ' → ' . htmlspecialchars($e['date_fin']) : '' ?>
              </div>
              <?php if ($e['description']): ?>
              <p class="event-desc"><?= htmlspecialchars($e['description']) ?></p>
              <?php endif; ?>
              <div class="card-footer">
                <span class="cap-badge">
                  <?php if ($cap): ?>
                    <?= $cnt ?> / <?= $cap ?> pers.
                    <?php if ($is_full): ?><span style="color:#dc2626;font-weight:600;"> · Complet</span><?php endif; ?>
                  <?php else: ?>
                    <?= $cnt ?> participant(s)
                  <?php endif; ?>
                </span>
                <?php if (isset($joined[$e['id']])): ?>
                  <a href="join_event.php?event_id=<?= $e['id'] ?>&action=leave" class="btn-leave">Quitter</a>
                <?php elseif ($is_full): ?>
                  <span class="btn-join" style="opacity:0.4;cursor:not-allowed;pointer-events:none;">Complet</span>
                <?php else: ?>
                  <a href="join_event.php?event_id=<?= $e['id'] ?>&action=join" class="btn-join">Rejoindre</a>
                <?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

      <?php elseif ($tab === 'mine'): ?>
        <?php $mine_events = array_filter($active_events, fn($e) => isset($joined[$e['id']])); ?>
        <?php if (empty($mine_events)): ?>
          <div class="empty">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <rect x="3" y="4" width="18" height="18" rx="2"/>
              <line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/>
              <line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
            <p>Vous ne participez à aucun événement.</p>
          </div>
        <?php else: ?>
          <div class="events-grid">
            <?php foreach ($mine_events as $e): ?>
            <div class="event-card">
              <h3><?= htmlspecialchars($e['titre']) ?></h3>
              <?php if ($e['lieu']): ?>
              <div class="event-meta">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
                <?= htmlspecialchars($e['lieu']) ?>
              </div>
              <?php endif; ?>
              <div class="event-meta">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="3" y="4" width="18" height="18" rx="2"/>
                  <line x1="3" y1="10" x2="21" y2="10"/>
                </svg>
                <?= htmlspecialchars($e['date_debut']) ?>
                <?= $e['date_fin'] ? ' → ' . htmlspecialchars($e['date_fin']) : '' ?>
              </div>
              <?php if ($e['description']): ?>
              <p class="event-desc"><?= htmlspecialchars($e['description']) ?></p>
              <?php endif; ?>
              <div class="card-footer">
                <span class="cap-badge" style="font-size:11px;color:var(--gray-400);">
                  Inscrit en tant que : <strong><?= htmlspecialchars($joined[$e['id']]) ?></strong>
                </span>
                <a href="join_event.php?event_id=<?= $e['id'] ?>&action=leave" class="btn-leave">Quitter</a>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($view === 'back'): ?>
  <div id="view-back">
    <div class="back-layout">
      <aside class="sidebar">
        <div class="sidebar-logo">
          <div class="logo-circle small">
            <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/></svg>
          </div>
          Booking
        </div>
        <nav>
          <div class="nav-item active">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="4" width="18" height="18" rx="2"/>
              <line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/>
              <line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
            Événements
          </div>
        </nav>
      </aside>

      <main class="back-main">
        <div class="back-topbar">
          <div class="admin-info">
            <span>Back-Office Admin</span>
            <div class="avatar"></div>
          </div>
          <div class="page-header">
            <div class="page-title">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="4" width="18" height="18" rx="2"/>
                <line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
              Liste des Événements
            </div>
            <a href="?view=back&modal" class="btn-primary">+ Nouvel Événement</a>
          </div>
        </div>

        <div class="table-card">
          <table>
            <thead>
              <tr>
                <th>Titre</th>
                <th>Date début</th>
                <th>Lieu</th>
                <th>Capacité</th>
                <th>Inscrits</th>
                <th>Statut</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($events)): ?>
              <tr><td colspan="7">
                <div class="empty">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <rect x="3" y="4" width="18" height="18" rx="2"/>
                    <line x1="16" y1="2" x2="16" y2="6"/>
                    <line x1="8" y1="2" x2="8" y2="6"/>
                    <line x1="3" y1="10" x2="21" y2="10"/>
                  </svg>
                  <p>Aucun événement pour le moment.</p>
                </div>
              </td></tr>
              <?php else: ?>
                <?php foreach ($events as $e): ?>
                <?php
                  $cnt_e  = $counts_map[$e['id']] ?? 0;
                  $cap_e  = $e['capacite_max'];
                  $full_e = $cap_e !== null && $cnt_e >= (int)$cap_e;
                ?>
                <tr class="data-row">
                  <td class="td-title"><?= htmlspecialchars($e['titre']) ?></td>
                  <td><?= htmlspecialchars($e['date_debut']) ?></td>
                  <td><?= htmlspecialchars($e['lieu'] ?? '—') ?></td>
                  <td><?= $e['capacite_max'] ?? '—' ?></td>
                  <td>
                    <span style="font-weight:600;color:<?= $full_e ? '#dc2626' : 'var(--gray-900)' ?>;">
                      <?= $cnt_e ?><?= $cap_e ? ' / ' . $cap_e : '' ?>
                    </span>
                    <?php if ($full_e): ?><span class="status-inactive" style="margin-left:4px;">Complet</span><?php endif; ?>
                  </td>
                  <td>
                    <?php if ($e['statut'] === 'active'): ?>
                      <span class="status-active">Actif</span>
                    <?php else: ?>
                      <span class="status-inactive">Inactif</span>
                    <?php endif; ?>
                  </td>
                  <td class="td-actions">
                    <a href="participants.php?event_id=<?= $e['id'] ?>" class="btn-activate" style="background:#EEF0FF;color:var(--purple);">Participants</a>
                    <a href="?view=back&edit=<?= $e['id'] ?>" class="btn-activate">Modifier</a>
                    <a href="delete_event.php?id=<?= $e['id'] ?>" class="btn-delete"
                       onclick="return confirm('Supprimer cet événement ?')">Supprimer</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  </div>

  <?php if ($show_modal): ?>
  <div class="modal-overlay open">
    <div class="modal">
      <div class="modal-header">
        <h2>Créer un événement</h2>
        <a href="?view=back" class="modal-close">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </a>
      </div>
      <form action="add_event.php" method="POST" onsubmit="return validateForm()">
        <div class="modal-body">
          <?php if (!empty($_GET['errors'])): ?>
          <div style="background:#fee2e2;color:#991b1b;border-radius:6px;padding:10px 14px;font-size:13px;margin-bottom:12px;">
            <?php foreach (explode('|', $_GET['errors']) as $err): ?>
              <div>• <?= htmlspecialchars($err) ?></div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <div class="form-group">
            <label for="f-titre">Titre <</label>
            <input type="text" id="f-titre" name="titre" value="<?= htmlspecialchars($f['titre']) ?>" placeholder="Ex: Conférence annuelle 2026"  />
          </div>
          <div class="form-group">
            <label for="f-desc">Description</label>
            <textarea id="f-desc" name="description" placeholder="Décrivez l'événement..."><?= htmlspecialchars($f['description']) ?></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="f-datedeb">Date de début </label>
              <input type="date" id="f-datedeb" name="date_debut" value="<?= htmlspecialchars($f['date_debut']) ?>"  />
            </div>
            <div class="form-group">
              <label for="f-datefin">Date de fin</label>
              <input type="date" id="f-datefin" name="date_fin" value="<?= htmlspecialchars($f['date_fin']) ?>" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="f-lieu">Lieu</label>
              <input type="text" id="f-lieu" name="lieu" value="<?= htmlspecialchars($f['lieu']) ?>" placeholder="Ex: Tunis, Salle A" />
            </div>
            <div class="form-group">
              <label for="f-cap">Capacité max</label>
              <input type="number" id="f-cap" name="capacite_max" value="<?= htmlspecialchars($f['capacite_max']) ?>" placeholder="100" min="1" />
            </div>
          </div>
          <div class="form-group">
            <label for="f-statut">Statut</label>
            <select id="f-statut" name="statut">
              <option value="active"   <?= $f['statut'] === 'active'   ? 'selected' : '' ?>>Actif</option>
              <option value="inactive" <?= $f['statut'] === 'inactive' ? 'selected' : '' ?>>Inactif</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <a href="?view=back" class="btn-cancel">Annuler</a>
          <button type="submit" class="btn-primary" >Créer l'événement</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($edit_id > 0 && $edit_event): ?>
  <?php
    $ef = !empty($_GET['errors']) ? $f : [
        'titre'        => $edit_event['titre'],
        'description'  => $edit_event['description'] ?? '',
        'date_debut'   => $edit_event['date_debut'],
        'date_fin'     => $edit_event['date_fin'] ?? '',
        'lieu'         => $edit_event['lieu'] ?? '',
        'capacite_max' => $edit_event['capacite_max'] ?? '',
        'statut'       => $edit_event['statut'],
    ];
  ?>
  <div class="modal-overlay open">
    <div class="modal">
      <div class="modal-header">
        <h2>Modifier l'événement</h2>
        <a href="?view=back" class="modal-close">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </a>
      </div>
      <form action="update_event.php" method="POST">
        <input type="hidden" name="id" value="<?= $edit_id ?>" />
        <div class="modal-body">
          <?php if (!empty($_GET['errors'])): ?>
          <div style="background:#fee2e2;color:#991b1b;border-radius:6px;padding:10px 14px;font-size:13px;margin-bottom:12px;">
            <?php foreach (explode('|', $_GET['errors']) as $err): ?>
              <div>• <?= htmlspecialchars($err) ?></div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <div class="form-group">
            <label for="e-titre">Titre <</label>
            <input type="text" id="e-titre" name="titre" value="<?= htmlspecialchars($ef['titre']) ?>" placeholder="Ex: Conférence annuelle 2026" />
          </div>
          <div class="form-group">
            <label for="e-desc">Description</label>
            <textarea id="e-desc" name="description" placeholder="Décrivez l'événement..."><?= htmlspecialchars($ef['description']) ?></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="e-datedeb">Date de début </label>
              <input type="date" id="e-datedeb" name="date_debut" value="<?= htmlspecialchars($ef['date_debut']) ?>" />
            </div>
            <div class="form-group">
              <label for="e-datefin">Date de fin</label>
              <input type="date" id="e-datefin" name="date_fin" value="<?= htmlspecialchars($ef['date_fin']) ?>" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="e-lieu">Lieu</label>
              <input type="text" id="e-lieu" name="lieu" value="<?= htmlspecialchars($ef['lieu']) ?>" placeholder="Ex: Tunis, Salle A" />
            </div>
            <div class="form-group">
              <label for="e-cap">Capacité max</label>
              <input type="number" id="e-cap" name="capacite_max" value="<?= htmlspecialchars($ef['capacite_max']) ?>" placeholder="100" min="1" />
            </div>
          </div>
          <div class="form-group">
            <label for="e-statut">Statut</label>
            <select id="e-statut" name="statut">
              <option value="active"   <?= $ef['statut'] === 'active'   ? 'selected' : '' ?>>Actif</option>
              <option value="inactive" <?= $ef['statut'] === 'inactive' ? 'selected' : '' ?>>Inactif</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <a href="?view=back" class="btn-cancel">Annuler</a>
          <button type="submit" class="btn-primary">Enregistrer</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <?php endif; ?>
<script src="validation.js"></script>
</body>
</html>
