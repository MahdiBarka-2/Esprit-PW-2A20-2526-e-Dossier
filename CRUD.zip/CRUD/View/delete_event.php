<?php
include __DIR__ . '/../controllers/EvenementController.php';

$controller = new EvenementC();

$controller->deleteEvenement($_GET['id']);

header("Location: index.php?view=back");
exit;
?>