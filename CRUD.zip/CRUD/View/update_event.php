<?php
include __DIR__ . '/../controllers/EvenementController.php';

$controller = new EvenementC();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
$controller-> updateEvenement($_POST['id'],$_POST);
header("Location: index.php?view=back");
    exit;
}
?>