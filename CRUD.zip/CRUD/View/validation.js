function validateForm() {

    const titre = document.getElementById("f-titre").value.trim();
    const dateDebut = document.getElementById("f-datedeb").value;
    const dateFin = document.getElementById("f-datefin").value;
    const capacite = document.getElementById("f-cap").value;
    const lieu = document.getElementById("f-lieu").value.trim();

    let errors = [];

    if (titre === "") {
        errors.push("Le titre est obligatoire.");
    }

    if (dateDebut === "") {
        errors.push("La date de début est obligatoire.");
    }

    if (dateFin !== "" && dateFin < dateDebut) {
        errors.push("La date de fin doit être après la date de début.");
    }

    if (capacite === "" || parseInt(capacite) <= 0) {
        errors.push("Le nombre de participants doit être supérieur à 0.");
    }

    if (lieu === "") {
        errors.push("Le lieu est obligatoire.");
    }

    if (errors.length > 0) {
        alert(errors.join("\n"));
        return false; // ❌ stop submit
    }

    return true; // ✅ allow submit
}