<?php
require_once __DIR__ . '/../View/config.php';
require_once __DIR__ . '/../models/EvenementModel.php';
class EvenementC
{
    public function listeEvenement()
    {
        $db = config::getConnexion();
        try {
            $liste = $db->query('SELECT * FROM evenements');
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    public function addEvenement($event)
    {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('INSERT INTO evenements (titre, description, date_debut, date_fin, lieu, capacite_max, statut)
                                VALUES (:titre, :description, :date_debut, :date_fin, :lieu, :capacite_max, :statut)');
            $req->execute([
                'titre' => $event['titre'],
                'description' => $event['description'],
                'date_debut' => $event['date_debut'],
                'date_fin' => $event['date_fin'],
                'lieu' => $event['lieu'],
                'capacite_max' => $event['capacite_max'],
                'statut' => $event['statut']
            ]);
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    public function deleteEvenement($id)
    {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('DELETE FROM evenements WHERE id = :id');
            $req->execute(['id' => $id]);
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    public function updateEvenement($id, $event)
    {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('UPDATE evenements
                SET titre = :titre,
                    description = :description,
                    date_debut = :date_debut,
                    date_fin = :date_fin,
                    lieu = :lieu,
                    capacite_max = :capacite_max,
                    statut = :statut
                WHERE id = :id');

            $req->execute([
                'id' => $id,
                'titre' => $event['titre'],
                'description' => $event['description'],
                'date_debut' => $event['date_debut'],
                'date_fin' => $event['date_fin'],
                'lieu' => $event['lieu'],
                'capacite_max' => $event['capacite_max'],
                'statut' => $event['statut']
            ]);
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    public function getEvenement($id)
    {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('SELECT * FROM evenements WHERE id = :id');
            $req->execute(['id' => $id]);
            return $req->fetch();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
    public function findAll()
{
    $db = config::getConnexion();
    return $db->query("SELECT * FROM evenements")->fetchAll();
}

public function findActive()
{
    $db = config::getConnexion();
    $stmt = $db->prepare("SELECT * FROM evenements WHERE statut = 'active'");
    $stmt->execute();
    return $stmt->fetchAll();
}

public function findById($id)
{
    $db = config::getConnexion();
    $stmt = $db->prepare("SELECT * FROM evenements WHERE id = :id");
    $stmt->execute(['id' => $id]);
    return $stmt->fetch();
}
}